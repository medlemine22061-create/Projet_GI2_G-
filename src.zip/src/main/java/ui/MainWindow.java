package ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import model.CollectionCenter;
import model.DeliveryRequest;
import model.Hospital;
import model.MapModel;
import model.MedicalSite;
import model.MedicalStaff;
import model.Mission;
import model.Position;
import model.enums.PriorityLevel;
import service.ImportExportService;
import service.OptimizationService;

import java.util.List;
import java.util.Optional;

/**
 * Main JavaFX window — Organ Drone Delivery.
 *
 * Design: dark medical theme (#0A1428 background, teal/cyan accents).
 * Layout: sidebar on the left, map canvas in the center, log at the bottom.
 */
public class MainWindow extends BorderPane {

    // ── Services ──────────────────────────────────────────────────────────────
    private final MapModel mapModel;
    private final OptimizationService optimizationService;
    private final ImportExportService importExportService;
    private final MedicalStaff defaultDoctor;

    // ── UI components ─────────────────────────────────────────────────────────
    private final MapCanvas mapCanvas;
    private final TextArea  logArea;
    private Mission currentMission;

    // ── Style constants ────────────────────────────────────────────────────────
    private static final String ROOT_STYLE =
            "-fx-background-color: #0A1428;";

    private static final String SIDEBAR_STYLE =
            "-fx-background-color: #0D1E3A; -fx-border-color: #1E3A6A;"
                    + " -fx-border-width: 0 1 0 0;";

    private static final String HEADER_STYLE =
            "-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #50C8FF;"
                    + " -fx-font-family: 'Monospace';";

    private static final String SECTION_LABEL_STYLE =
            "-fx-font-size: 10px; -fx-text-fill: #4A7AAA; -fx-font-family: 'Monospace';"
                    + " -fx-font-weight: bold;";

    private static final String LOG_STYLE =
            "-fx-background-color: #060F20; -fx-control-inner-background: #060F20;"
                    + " -fx-text-fill: #7ABFFF; -fx-font-family: 'Monospace'; -fx-font-size: 11px;"
                    + " -fx-border-color: #1E3A6A; -fx-border-width: 1 0 0 0;";

    // ── Constructor ───────────────────────────────────────────────────────────

    public MainWindow(MapModel mapModel, OptimizationService optimizationService,
                      ImportExportService importExportService, MedicalStaff defaultDoctor) {
        this.mapModel            = mapModel;
        this.optimizationService = optimizationService;
        this.importExportService = importExportService;
        this.defaultDoctor       = defaultDoctor;

        this.mapCanvas = new MapCanvas(mapModel);
        this.logArea   = new TextArea();

        initLayout();
    }

    // ── Layout ────────────────────────────────────────────────────────────────

    private void initLayout() {
        setStyle(ROOT_STYLE);

        // Header bar
        HBox header = buildHeader();

        // Sidebar
        ScrollPane sidebar = buildSidebar();

        // Log area
        logArea.setEditable(false);
        logArea.setPrefHeight(100);
        logArea.setStyle(LOG_STYLE);
        logArea.setText("▶  System ready.\n");

        setTop(header);
        setLeft(sidebar);
        setCenter(mapCanvas);
        setBottom(logArea);

        mapCanvas.draw();
    }

    private HBox buildHeader() {
        HBox bar = new HBox();
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(10, 20, 10, 20));
        bar.setStyle("-fx-background-color: #060F20;"
                + " -fx-border-color: #1E3A6A; -fx-border-width: 0 0 1 0;");

        // Red cross icon simulation via text
        Label cross = new Label("✚");
        cross.setStyle("-fx-text-fill: #00DC82; -fx-font-size: 18px;");

        Label title = new Label("  MEDADRONE  —  Organ Delivery System");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;"
                + " -fx-text-fill: #D2E6FF; -fx-font-family: 'Monospace';");

        bar.getChildren().addAll(cross, title);
        return bar;
    }

    private ScrollPane buildSidebar() {
        VBox panel = new VBox(6);
        panel.setPadding(new Insets(14, 12, 14, 12));
        panel.setPrefWidth(220);
        panel.setStyle(SIDEBAR_STYLE);

        // ── Section: Sites ─────────────────────────────────────────────────
        panel.getChildren().add(sectionLabel("MEDICAL SITES"));
        panel.getChildren().add(btn("＋  Add Hospital",           "#00DC82", e -> addHospital()));
        panel.getChildren().add(btn("＋  Add Collection Center",   "#FFB040", e -> addCollectionCenter()));
        panel.getChildren().add(btn("✕  Remove Site",             "#FF6060", e -> removeSite()));
        panel.getChildren().add(btn("↔  Move Site",               "#50C8FF", e -> moveSite()));
        panel.getChildren().add(separator());

        // ── Section: Import / Export ───────────────────────────────────────
        panel.getChildren().add(sectionLabel("MAP DATA"));
        panel.getChildren().add(btn("⬆  Import CSV",              "#50C8FF", e -> importCsv()));
        panel.getChildren().add(btn("💾  Export Map",              "#8C64FF", e -> exportMap()));
        panel.getChildren().add(btn("📂  Import Map",              "#8C64FF", e -> importMap()));
        panel.getChildren().add(separator());

        // ── Section: Diagnostics ──────────────────────────────────────────
        panel.getChildren().add(sectionLabel("DIAGNOSTICS"));
        panel.getChildren().add(btn("📊  Statistics",              "#50C8FF", e -> displayStats()));
        panel.getChildren().add(btn("🔍  Find Nearest Site",       "#50C8FF", e -> findNearest()));
        panel.getChildren().add(separator());

        // ── Section: Mission ──────────────────────────────────────────────
        panel.getChildren().add(sectionLabel("MISSION CONTROL"));
        panel.getChildren().add(btn("🚀  Create Mission",          "#00DC82", e -> createMission()));
        panel.getChildren().add(btn("▶   Launch & Animate",        "#FFB040", e -> startMission()));
        panel.getChildren().add(btn("📡  Track Mission",           "#50C8FF", e -> trackMission()));
        panel.getChildren().add(btn("✔   Complete Mission",        "#00DC82", e -> completeMission()));
        panel.getChildren().add(btn("✕   Cancel Mission",          "#FF6060", e -> cancelMission()));

        ScrollPane scroll = new ScrollPane(panel);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: transparent;"
                + " -fx-background: transparent;"
                + " -fx-border-color: transparent;");
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        return scroll;
    }

    // ── Button factory ────────────────────────────────────────────────────────

    private Button btn(String text, String accentHex,
                       javafx.event.EventHandler<javafx.event.ActionEvent> handler) {
        Button b = new Button(text);
        b.setMaxWidth(Double.MAX_VALUE);
        b.setAlignment(Pos.CENTER_LEFT);
        b.setPadding(new Insets(7, 10, 7, 10));
        b.setStyle(
                "-fx-background-color: #122040;"
                        + " -fx-text-fill: " + accentHex + ";"
                        + " -fx-font-family: 'Monospace';"
                        + " -fx-font-size: 11px;"
                        + " -fx-background-radius: 5;"
                        + " -fx-cursor: hand;"
        );
        b.setOnMouseEntered(e -> b.setStyle(
                "-fx-background-color: #1E3A6A;"
                        + " -fx-text-fill: " + accentHex + ";"
                        + " -fx-font-family: 'Monospace';"
                        + " -fx-font-size: 11px;"
                        + " -fx-background-radius: 5;"
                        + " -fx-cursor: hand;"
        ));
        b.setOnMouseExited(e -> b.setStyle(
                "-fx-background-color: #122040;"
                        + " -fx-text-fill: " + accentHex + ";"
                        + " -fx-font-family: 'Monospace';"
                        + " -fx-font-size: 11px;"
                        + " -fx-background-radius: 5;"
                        + " -fx-cursor: hand;"
        ));
        b.setOnAction(handler);
        return b;
    }

    private Label sectionLabel(String text) {
        Label l = new Label(text);
        l.setStyle(SECTION_LABEL_STYLE);
        l.setPadding(new Insets(8, 0, 2, 0));
        return l;
    }

    private Separator separator() {
        Separator s = new Separator();
        s.setStyle("-fx-background-color: #1E3A6A;");
        return s;
    }

    // ── Actions ───────────────────────────────────────────────────────────────

    private void addHospital() {
        try {
            String id   = ask("Hospital ID (e.g. H3)");
            String name = ask("Hospital name");
            double x    = askDouble("X coordinate (0 – 850)");
            double y    = askDouble("Y coordinate (0 – 620)");

            mapModel.addMedicalSite(new Hospital(id, name, new Position(x, y), true));
            refresh("✚  Hospital added: " + name);
        } catch (Exception e) {
            err(e.getMessage());
        }
    }

    private void addCollectionCenter() {
        try {
            String id     = ask("Collection center ID (e.g. C3)");
            String name   = ask("Collection center name");
            double x      = askDouble("X coordinate (0 – 850)");
            double y      = askDouble("Y coordinate (0 – 620)");
            String organs = ask("Organ types separated by comma (e.g. Kidney,Heart,Liver)");

            mapModel.addMedicalSite(new CollectionCenter(
                    id, name, new Position(x, y),
                    java.util.Arrays.asList(organs.split(","))
            ));
            refresh("✚  Collection center added: " + name);
        } catch (Exception e) {
            err(e.getMessage());
        }
    }

    private void removeSite() {
        try {
            String id = ask("ID of the site to remove");
            MedicalSite site = mapModel.findMedicalSiteById(id);

            if (site == null) {
                err("No site found with ID: " + id);
                return;
            }

            mapModel.removeMedicalSite(site);
            refresh("✕  Site removed: " + site.getName());
        } catch (Exception e) {
            err(e.getMessage());
        }
    }

    private void moveSite() {
        try {
            String id = ask("ID of the site to move");
            MedicalSite site = mapModel.findMedicalSiteById(id);

            if (site == null) {
                err("No site found with ID: " + id);
                return;
            }

            double x = askDouble("New X coordinate");
            double y = askDouble("New Y coordinate");

            mapModel.moveMedicalSite(site, new Position(x, y));
            refresh("↔  Site moved: " + site.getName() + " → (" + (int)x + ", " + (int)y + ")");
        } catch (Exception e) {
            err(e.getMessage());
        }
    }

    private void importCsv() {
        try {
            String path = ask("CSV file path (e.g. sites.csv)");
            importExportService.importMedicalSitesFromCsv(mapModel, path);
            refresh("⬆  CSV imported from: " + path);
        } catch (Exception e) {
            err(e.getMessage());
        }
    }

    private void exportMap() {
        try {
            String path = ask("Export file path (e.g. map.bin)");
            importExportService.exportMap(mapModel, path);
            log("💾  Map exported to: " + path);
        } catch (Exception e) {
            err(e.getMessage());
        }
    }

    private void importMap() {
        try {
            String path = ask("Import file path (e.g. map.bin)");
            importExportService.importMap(path);
            log("📂  Map imported from: " + path);
            info("Import successful", "Restart the app to load the imported map.");
        } catch (Exception e) {
            err(e.getMessage());
        }
    }

    private void displayStats() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n── STATISTICS ─────────────────────\n");
        sb.append("  Hospitals        : ").append(mapModel.getHospitals().size()).append("\n");
        sb.append("  Collection ctrs  : ").append(mapModel.getCollectionCenters().size()).append("\n");
        sb.append("  Drone bases      : ").append(mapModel.getDroneBases().size()).append("\n");
        sb.append("  Drones           : ").append(mapModel.getDrones().size()).append("\n");
        sb.append("  Voronoi cells    : ").append(mapModel.getVoronoiDiagram().getCells().size()).append("\n");
        sb.append("  Delaunay tri.    : ").append(mapModel.getDelaunayTriangulation().getTriangles().size()).append("\n");

        // Per-cell stats
        sb.append("\n── VORONOI ZONE DETAILS ────────────\n");
        for (var cell : mapModel.getVoronoiDiagram().getCells()) {
            sb.append(String.format("  %-22s | surface: %5.0f | density: %.5f\n",
                    cell.getOwner().getName(),
                    cell.getSurface(),
                    cell.getDensity()
            ));
        }

        log(sb.toString());
    }

    private void findNearest() {
        try {
            double x = askDouble("X coordinate");
            double y = askDouble("Y coordinate");

            MedicalSite nearest = mapModel.getVoronoiDiagram().getNearestSite(new Position(x, y));

            if (nearest == null) {
                log("  No site found.");
            } else {
                log("🔍  Nearest site: [" + nearest.getId() + "]  " + nearest.getName());
            }
        } catch (Exception e) {
            err(e.getMessage());
        }
    }

    private void createMission() {
        try {
            // Let the user pick origin and destination by ID
            String originId = ask("Collection center ID for origin");
            String destId   = ask("Hospital ID for destination");

            CollectionCenter origin = findCenter(originId);
            Hospital destination    = findHospital(destId);

            if (origin == null) { err("Collection center not found: " + originId); return; }
            if (destination == null) { err("Hospital not found: " + destId); return; }

            String organ = ask("Organ type (e.g. Kidney, Heart, Liver)");

            DeliveryRequest request = defaultDoctor.createDeliveryRequest(
                    origin, destination, organ, PriorityLevel.CRITICAL
            );

            currentMission = optimizationService.createMission(request, mapModel.getDrones());
            mapCanvas.setCurrentMission(currentMission);

            refresh(String.format(
                    "🚀  Mission created\n"
                            + "    Drone   : %s\n"
                            + "    From    : %s\n"
                            + "    To      : %s\n"
                            + "    Organ   : %s\n"
                            + "    Distance: %.1f units",
                    currentMission.getDrone().getId(),
                    origin.getName(),
                    destination.getName(),
                    organ,
                    currentMission.getRoute().computeDistance()
            ));
        } catch (Exception e) {
            err(e.getMessage());
        }
    }

    private void startMission() {
        if (currentMission == null) { err("No mission created yet."); return; }

        currentMission.start();
        mapCanvas.startDroneAnimation();
        log("▶   Mission launched — drone is flying…");
    }

    private void trackMission() {
        if (currentMission == null) { err("No current mission."); return; }

        log(String.format(
                "\n── MISSION TRACKING ────────────────\n"
                        + "  ID       : %s\n"
                        + "  Status   : %s\n"
                        + "  Drone    : %s\n"
                        + "  Battery  : %.0f%%\n"
                        + "  Position : (%.0f, %.0f)\n"
                        + "  Reception: %s",
                currentMission.getId(),
                currentMission.getStatus(),
                currentMission.getDrone().getId(),
                currentMission.getBatteryLevel(),
                currentMission.getCurrentPosition().getX(),
                currentMission.getCurrentPosition().getY(),
                currentMission.isReceptionConfirmed() ? "Confirmed ✔" : "Pending"
        ));
    }

    private void completeMission() {
        if (currentMission == null) { err("No current mission."); return; }

        currentMission.complete();
        currentMission.getRequest().getDestination().receiveMission(currentMission);
        defaultDoctor.validateReception(currentMission);
        refresh("✔   Mission completed — organ delivered successfully.");
    }

    private void cancelMission() {
        if (currentMission == null) { err("No current mission."); return; }

        currentMission.cancel();
        refresh("✕   Mission cancelled.");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private CollectionCenter findCenter(String id) {
        for (CollectionCenter c : mapModel.getCollectionCenters()) {
            if (c.getId().equalsIgnoreCase(id)) return c;
        }
        return null;
    }

    private Hospital findHospital(String id) {
        for (Hospital h : mapModel.getHospitals()) {
            if (h.getId().equalsIgnoreCase(id)) return h;
        }
        return null;
    }

    private String ask(String prompt) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Input required");
        dialog.setHeaderText(null);
        dialog.setContentText(prompt + ":");
        dialog.getDialogPane().setStyle(
                "-fx-background-color: #0D1E3A; -fx-text-fill: #D2E6FF;"
        );

        Optional<String> result = dialog.showAndWait();

        if (result.isEmpty() || result.get().isBlank()) {
            throw new IllegalArgumentException("Input cannot be empty.");
        }
        return result.get().trim();
    }

    private double askDouble(String prompt) {
        try {
            return Double.parseDouble(ask(prompt));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Please enter a valid number.");
        }
    }

    private void refresh(String msg) {
        mapCanvas.draw();
        log(msg);
    }

    private void log(String msg) {
        logArea.appendText(msg + "\n");
    }

    private void err(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle("Error");
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
        log("⚠   " + msg);
    }

    private void info(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
}