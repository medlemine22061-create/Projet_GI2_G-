package ui;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import model.CollectionCenter;
import model.Drone;
import model.DroneBase;
import model.Hospital;
import model.MapModel;
import model.MedicalSite;
import model.Mission;
import model.Position;
import model.Route;
import model.Triangle;
import model.UserPoint;
import model.VoronoiCell;

import java.util.ArrayList;
import java.util.List;

/**
 * Canvas used to draw the map with a medical/drone delivery theme.
 * Handles Voronoi zones, Delaunay triangulation, drone animation,
 * mouse interaction (click and hover).
 */
public class MapCanvas extends Canvas {

    // ── Design tokens ────────────────────────────────────────────────────────
    private static final Color BG_DARK       = Color.rgb(10,  20,  40);
    private static final Color BG_GRID       = Color.rgb(25,  45,  80);
    private static final Color HOSPITAL_CLR  = Color.rgb(0,   220, 130);
    private static final Color CENTER_CLR    = Color.rgb(255, 165, 50);
    private static final Color DRONE_CLR     = Color.rgb(80,  180, 255);
    private static final Color BASE_CLR      = Color.rgb(140, 100, 255);
    private static final Color ROUTE_CLR     = Color.rgb(255, 80,  80);
    private static final Color DELAUNAY_CLR  = Color.rgb(100, 160, 255, 0.45);
    private static final Color TEXT_CLR      = Color.rgb(210, 230, 255);
    private static final Color PANEL_BG      = Color.rgb(15,  30,  60,  0.88);

    // Voronoi zone palette (one per site, cycling)
    private static final Color[] VORONOI_COLORS = {
            Color.rgb(0,   180, 120, 0.18),
            Color.rgb(80,  130, 255, 0.18),
            Color.rgb(255, 140, 40,  0.18),
            Color.rgb(180, 60,  255, 0.18),
            Color.rgb(255, 60,  120, 0.18),
            Color.rgb(60,  220, 255, 0.18),
    };

    private static final Color[] VORONOI_BORDER = {
            Color.rgb(0,   220, 150, 0.55),
            Color.rgb(100, 160, 255, 0.55),
            Color.rgb(255, 180, 60,  0.55),
            Color.rgb(200, 80,  255, 0.55),
            Color.rgb(255, 80,  140, 0.55),
            Color.rgb(80,  240, 255, 0.55),
    };

    // ── State ─────────────────────────────────────────────────────────────────
    private final MapModel mapModel;
    private Mission currentMission;

    /** Animated drone position along the route (0.0 → 1.0). */
    private double droneAnimProgress = 0.0;
    private boolean animating = false;
    private AnimationTimer animationTimer;

    /** Currently hovered / selected site for info panel. */
    private MedicalSite hoveredSite   = null;
    private VoronoiCell selectedCell  = null;

    // ── Constructor ───────────────────────────────────────────────────────────
    public MapCanvas(MapModel mapModel) {
        super(900, 650);
        this.mapModel = mapModel;

        widthProperty().addListener(e -> draw());
        heightProperty().addListener(e -> draw());

        setupMouseHandlers();
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Sets the current mission and starts the drone animation.
     */
    public void setCurrentMission(Mission mission) {
        this.currentMission = mission;
        this.droneAnimProgress = 0.0;
        draw();
    }

    /**
     * Starts the animated drone flight along the mission route.
     */
    public void startDroneAnimation() {
        if (currentMission == null) return;
        if (animating) return;

        animating = true;
        droneAnimProgress = 0.0;

        animationTimer = new AnimationTimer() {
            private long lastTime = -1;

            @Override
            public void handle(long now) {
                if (lastTime < 0) { lastTime = now; return; }

                double elapsed = (now - lastTime) / 1_000_000_000.0;
                lastTime = now;

                // Speed: cross the full route in ~6 seconds
                droneAnimProgress += elapsed / 6.0;

                if (droneAnimProgress >= 1.0) {
                    droneAnimProgress = 1.0;
                    animating = false;
                    stop();
                }

                draw();
            }
        };

        animationTimer.start();
    }

    /**
     * Full redraw.
     */
    public void draw() {
        GraphicsContext gc = getGraphicsContext2D();
        drawBackground(gc);
        drawVoronoiZones(gc);
        drawDelaunay(gc);
        drawMedicalSites(gc);
        drawDroneBases(gc);
        drawDrones(gc);
        drawMissionRoute(gc);
        drawAnimatedDrone(gc);
        drawInfoPanel(gc);
        drawLegend(gc);
    }

    // ── Drawing layers ────────────────────────────────────────────────────────

    private void drawBackground(GraphicsContext gc) {
        gc.setFill(BG_DARK);
        gc.fillRect(0, 0, getWidth(), getHeight());

        // Subtle grid
        gc.setStroke(BG_GRID);
        gc.setLineWidth(0.5);
        for (int x = 0; x <= getWidth(); x += 50) {
            gc.strokeLine(x, 0, x, getHeight());
        }
        for (int y = 0; y <= getHeight(); y += 50) {
            gc.strokeLine(0, y, getWidth(), y);
        }
    }

    /**
     * Draws filled Voronoi zones using the grid points of each cell.
     * Each zone gets a distinct semi-transparent color with a colored border dot.
     */
    private void drawVoronoiZones(GraphicsContext gc) {
        List<VoronoiCell> cells = mapModel.getVoronoiDiagram().getCells();

        for (int idx = 0; idx < cells.size(); idx++) {
            VoronoiCell cell = cells.get(idx);
            Color fill   = VORONOI_COLORS[idx % VORONOI_COLORS.length];
            Color border = VORONOI_BORDER[idx % VORONOI_BORDER.length];

            gc.setFill(fill);

            int counter = 0;
            for (Position point : cell.getPoints()) {
                if (counter % 1 == 0) {
                    gc.fillRect(point.getX() - 1, point.getY() - 1, 4, 4);
                }
                counter++;
            }

            // Highlight selected cell border
            if (cell.equals(selectedCell)) {
                gc.setStroke(border);
                gc.setLineWidth(2.0);
                for (Position point : cell.getPoints()) {
                    gc.strokeRect(point.getX() - 1, point.getY() - 1, 4, 4);
                }
            }
        }
    }

    private void drawDelaunay(GraphicsContext gc) {
        gc.setStroke(DELAUNAY_CLR);
        gc.setLineWidth(1.2);

        for (Triangle t : mapModel.getDelaunayTriangulation().getTriangles()) {
            Position a = t.getSiteA().getPosition();
            Position b = t.getSiteB().getPosition();
            Position c = t.getSiteC().getPosition();

            gc.strokeLine(a.getX(), a.getY(), b.getX(), b.getY());
            gc.strokeLine(b.getX(), b.getY(), c.getX(), c.getY());
            gc.strokeLine(c.getX(), c.getY(), a.getX(), a.getY());
        }
    }

    private void drawMedicalSites(GraphicsContext gc) {
        for (MedicalSite site : mapModel.getMedicalSites()) {
            double x = site.getPosition().getX();
            double y = site.getPosition().getY();

            boolean hovered = site.equals(hoveredSite);
            double radius = hovered ? 11 : 8;

            if (site instanceof Hospital) {
                // Glowing green circle
                if (hovered) {
                    gc.setFill(Color.rgb(0, 255, 150, 0.25));
                    gc.fillOval(x - 18, y - 18, 36, 36);
                }
                gc.setFill(HOSPITAL_CLR);
                gc.fillOval(x - radius, y - radius, radius * 2, radius * 2);

                // White cross
                gc.setStroke(Color.WHITE);
                gc.setLineWidth(2);
                gc.strokeLine(x - 4, y, x + 4, y);
                gc.strokeLine(x, y - 4, x, y + 4);

                drawLabel(gc, "H  " + site.getName(), x + 13, y + 4);

            } else if (site instanceof CollectionCenter) {
                if (hovered) {
                    gc.setFill(Color.rgb(255, 165, 50, 0.22));
                    gc.fillOval(x - 18, y - 18, 36, 36);
                }
                gc.setFill(CENTER_CLR);
                gc.fillRect(x - radius, y - radius, radius * 2, radius * 2);

                // Small organ icon (circle inside)
                gc.setFill(Color.WHITE);
                gc.fillOval(x - 3, y - 3, 6, 6);

                drawLabel(gc, "C  " + site.getName(), x + 13, y + 4);
            }
        }
    }

    private void drawDroneBases(GraphicsContext gc) {
        for (DroneBase base : mapModel.getDroneBases()) {
            double x = base.getPosition().getX();
            double y = base.getPosition().getY();

            // Hexagon-ish pad
            gc.setFill(BASE_CLR);
            double[] px = {x, x - 10, x - 10, x, x + 10, x + 10};
            double[] py = {y - 11, y - 5, y + 5, y + 11, y + 5, y - 5};
            gc.fillPolygon(px, py, 6);

            gc.setStroke(Color.WHITE);
            gc.setLineWidth(1.5);
            gc.strokePolygon(px, py, 6);

            drawLabel(gc, "Base  " + base.getName(), x + 14, y + 4);
        }
    }

    private void drawDrones(GraphicsContext gc) {
        // Only draw static drones when NOT animating a mission
        if (animating) return;

        for (Drone drone : mapModel.getDrones()) {
            double x = drone.getPosition().getX();
            double y = drone.getPosition().getY();

            drawDroneIcon(gc, x, y, DRONE_CLR, drone.getId());
        }
    }

    /**
     * Draws the mission route as a dashed colored path.
     * Origin → waypoints → destination.
     */
    private void drawMissionRoute(GraphicsContext gc) {
        if (currentMission == null) return;

        Route route = currentMission.getRoute();
        if (route == null) return;

        gc.setStroke(ROUTE_CLR);
        gc.setLineWidth(2.5);
        gc.setLineDashes(10, 6);

        Position current = route.getOrigin().getPosition();

        for (Position wp : route.getWaypoints()) {
            gc.strokeLine(current.getX(), current.getY(), wp.getX(), wp.getY());
            // Waypoint dot
            gc.setFill(ROUTE_CLR);
            gc.fillOval(wp.getX() - 4, wp.getY() - 4, 8, 8);
            current = wp;
        }

        Position dest = route.getDestination().getPosition();
        gc.strokeLine(current.getX(), current.getY(), dest.getX(), dest.getY());
        gc.setLineDashes(); // reset
    }

    /**
     * Draws the animated drone along the route using droneAnimProgress (0..1).
     */
    private void drawAnimatedDrone(GraphicsContext gc) {
        if (currentMission == null || !animating && droneAnimProgress <= 0) return;

        Route route = currentMission.getRoute();
        if (route == null) return;

        // Build full path: origin → waypoints → destination
        List<Position> path = new ArrayList<>();
        path.add(route.getOrigin().getPosition());
        path.addAll(route.getWaypoints());
        path.add(route.getDestination().getPosition());

        // Compute total length
        double totalDist = 0;
        for (int i = 0; i < path.size() - 1; i++) {
            totalDist += path.get(i).distanceTo(path.get(i + 1));
        }

        if (totalDist == 0) return;

        // Find position at droneAnimProgress * totalDist
        double target = droneAnimProgress * totalDist;
        double walked = 0;
        Position dronePos = path.get(path.size() - 1);

        for (int i = 0; i < path.size() - 1; i++) {
            Position from = path.get(i);
            Position to   = path.get(i + 1);
            double seg = from.distanceTo(to);

            if (walked + seg >= target) {
                double t = (target - walked) / seg;
                dronePos = new Position(
                        from.getX() + t * (to.getX() - from.getX()),
                        from.getY() + t * (to.getY() - from.getY())
                );
                break;
            }
            walked += seg;
        }

        // Glow effect
        gc.setFill(Color.rgb(80, 180, 255, 0.20));
        gc.fillOval(dronePos.getX() - 20, dronePos.getY() - 20, 40, 40);

        drawDroneIcon(gc, dronePos.getX(), dronePos.getY(),
                Color.rgb(255, 255, 100), currentMission.getDrone().getId());

        // Update model position for tracking
        currentMission.getDrone().updatePosition(dronePos);
    }

    /**
     * Draws a small drone icon (cross + rotors) at (x, y).
     */
    private void drawDroneIcon(GraphicsContext gc, double x, double y,
                               Color color, String label) {
        gc.setFill(color);
        gc.setStroke(color);
        gc.setLineWidth(2);

        // Body
        gc.fillOval(x - 5, y - 5, 10, 10);

        // Arms
        gc.strokeLine(x - 10, y - 10, x - 5, y - 5);
        gc.strokeLine(x + 5,  y - 5,  x + 10, y - 10);
        gc.strokeLine(x - 5,  y + 5,  x - 10, y + 10);
        gc.strokeLine(x + 5,  y + 5,  x + 10, y + 10);

        // Rotors
        gc.setFill(Color.rgb(255, 255, 255, 0.6));
        gc.fillOval(x - 14, y - 14, 8, 8);
        gc.fillOval(x + 6,  y - 14, 8, 8);
        gc.fillOval(x - 14, y + 6,  8, 8);
        gc.fillOval(x + 6,  y + 6,  8, 8);

        drawLabel(gc, label, x + 16, y + 4);
    }

    /**
     * Side panel showing info about the hovered / selected site.
     */
    private void drawInfoPanel(GraphicsContext gc) {
        if (hoveredSite == null && selectedCell == null) return;

        double px = getWidth() - 220;
        double py = 20;
        double pw = 200;
        double ph = 150;

        // Panel background
        gc.setFill(PANEL_BG);
        gc.fillRoundRect(px, py, pw, ph, 12, 12);
        gc.setStroke(Color.rgb(80, 160, 255, 0.6));
        gc.setLineWidth(1.2);
        gc.strokeRoundRect(px, py, pw, ph, 12, 12);

        gc.setFont(Font.font("Monospace", FontWeight.BOLD, 12));
        gc.setFill(Color.rgb(80, 200, 255));
        gc.fillText("SITE INFO", px + 12, py + 22);

        gc.setFont(Font.font("Monospace", FontWeight.NORMAL, 11));
        gc.setFill(TEXT_CLR);

        if (hoveredSite != null) {
            String type = (hoveredSite instanceof Hospital) ? "Hospital" : "Collection Center";
            gc.fillText("Name: " + hoveredSite.getName(), px + 12, py + 42);
            gc.fillText("Type: " + type,                  px + 12, py + 58);
            gc.fillText("X: " + (int) hoveredSite.getPosition().getX()
                    + "  Y: " + (int) hoveredSite.getPosition().getY(), px + 12, py + 74);
        }

        if (selectedCell != null) {
            gc.fillText("Requests: " + selectedCell.getNumberOfUserPoints(), px + 12, py + 96);
            gc.fillText("Surface:  " + (int) selectedCell.getSurface(),      px + 12, py + 112);
            gc.fillText("Density:  " + String.format("%.4f", selectedCell.getDensity()), px + 12, py + 128);
        }
    }

    private void drawLegend(GraphicsContext gc) {
        double x = 14;
        double y = getHeight() - 148;

        gc.setFill(PANEL_BG);
        gc.fillRoundRect(x - 8, y - 18, 195, 138, 10, 10);
        gc.setStroke(Color.rgb(80, 160, 255, 0.4));
        gc.setLineWidth(1);
        gc.strokeRoundRect(x - 8, y - 18, 195, 138, 10, 10);

        gc.setFont(Font.font("Monospace", FontWeight.BOLD, 11));
        gc.setFill(Color.rgb(80, 200, 255));
        gc.fillText("LEGEND", x, y);

        gc.setFont(Font.font("Monospace", FontWeight.NORMAL, 11));

        // Hospital
        gc.setFill(HOSPITAL_CLR);
        gc.fillOval(x, y + 12, 10, 10);
        gc.setFill(TEXT_CLR);
        gc.fillText("Hospital", x + 18, y + 21);

        // Collection center
        gc.setFill(CENTER_CLR);
        gc.fillRect(x, y + 30, 10, 10);
        gc.setFill(TEXT_CLR);
        gc.fillText("Collection Center", x + 18, y + 39);

        // Drone base
        gc.setFill(BASE_CLR);
        gc.fillOval(x, y + 48, 10, 10);
        gc.setFill(TEXT_CLR);
        gc.fillText("Drone Base", x + 18, y + 57);

        // Drone
        gc.setFill(DRONE_CLR);
        gc.fillOval(x, y + 66, 10, 10);
        gc.setFill(TEXT_CLR);
        gc.fillText("Drone", x + 18, y + 75);

        // Route
        gc.setStroke(ROUTE_CLR);
        gc.setLineWidth(2);
        gc.setLineDashes(6, 4);
        gc.strokeLine(x, y + 88, x + 10, y + 88);
        gc.setLineDashes();
        gc.setFill(TEXT_CLR);
        gc.fillText("Mission route", x + 18, y + 92);

        // Delaunay
        gc.setStroke(DELAUNAY_CLR);
        gc.setLineWidth(1.5);
        gc.strokeLine(x, y + 106, x + 10, y + 106);
        gc.setFill(TEXT_CLR);
        gc.fillText("Delaunay edge", x + 18, y + 110);
    }

    // ── Mouse interaction ─────────────────────────────────────────────────────

    private void setupMouseHandlers() {
        setOnMouseMoved(event -> {
            double mx = event.getX();
            double my = event.getY();

            MedicalSite found = findSiteAt(mx, my);

            if (found != hoveredSite) {
                hoveredSite = found;

                if (found != null) {
                    selectedCell = mapModel.getVoronoiDiagram().getCellBySite(found);
                }

                draw();
            }
        });

        setOnMouseClicked(event -> {
            double mx = event.getX();
            double my = event.getY();

            MedicalSite clicked = findSiteAt(mx, my);

            if (clicked != null) {
                hoveredSite = clicked;
                selectedCell = mapModel.getVoronoiDiagram().getCellBySite(clicked);
            } else {
                hoveredSite = null;
                selectedCell = null;
            }

            draw();
        });
    }

    /**
     * Returns the medical site within click/hover radius, or null.
     */
    private MedicalSite findSiteAt(double mx, double my) {
        for (MedicalSite site : mapModel.getMedicalSites()) {
            double dx = site.getPosition().getX() - mx;
            double dy = site.getPosition().getY() - my;

            if (Math.sqrt(dx * dx + dy * dy) < 14) {
                return site;
            }
        }
        return null;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void drawLabel(GraphicsContext gc, String text, double x, double y) {
        gc.setFont(Font.font("Monospace", FontWeight.NORMAL, 11));
        // Shadow
        gc.setFill(Color.rgb(0, 0, 0, 0.7));
        gc.fillText(text, x + 1, y + 1);
        // Label
        gc.setFill(TEXT_CLR);
        gc.fillText(text, x, y);
    }
}